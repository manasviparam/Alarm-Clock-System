#ifndef ALARM_WORKER_H
#define ALARM_WORKER_H

#include <sys/types.h>

/* Runs inside a freshly forked child process for one alarm.
 *
 * Lifecycle (every step is logged to the `events` table with the real
 * CPU core and timestamp, which the web UI plays back as the scheduler view):
 *   NEW -> RUNNING (setup) -> WAITING (sigsuspend) -> [SIGALRM]
 *       -> READY (run queue) -> RUNNING (handler, notification)
 *       -> WAITING (ringing, until SIGUSR2 = dismiss) -> RUNNING -> EXITED
 * SIGUSR1 cancels an alarm that has not fired yet.
 *
 * Never returns: it always calls exit() itself.
 */
void run_alarm_worker(const char *db_path, long long alarm_id, int delay_seconds,
                      const char *label, long long fork_us) __attribute__((noreturn));

#endif
