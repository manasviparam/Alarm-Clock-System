#ifndef SYSINFO_H
#define SYSINFO_H
#include <stddef.h>

/* Snapshot of the real Linux scheduler state read from /proc:
 * per-core usage, process counts by state, and details (state, last CPU,
 * CPU time, context switches) for the server, the alarm workers in
 * pids[] and a few other runnable processes. Returns bytes written or -1. */
int sysinfo_json(const int *pids, int npids, char *buf, size_t buflen);
#endif
