(() => {
  const $ = id => document.getElementById(id);
  const pad = n => String(n).padStart(2, '0');
  const h = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  const post = url => fetch(url, { method: 'POST' }).catch(() => {});
  const fmtT = ms => { const d = new Date(ms); return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}.${String(d.getMilliseconds()).padStart(3, '0')}`; };
  const fmtClock = ts => fmtT(ts * 1000).slice(0, 8);
  let mode = 'delay';

  /* ---------- clock + form ---------- */
  const tick = () => { $('clock').textContent = fmtT(Date.now()).slice(0, 8); };
  setInterval(tick, 1000); tick();
  document.querySelectorAll('.toggle-btn').forEach(b => b.addEventListener('click', () => {
    document.querySelectorAll('.toggle-btn').forEach(x => x.classList.toggle('active', x === b));
    mode = b.dataset.mode;
    $('delay-fields').classList.toggle('hidden', mode !== 'delay');
    $('time-fields').classList.toggle('hidden', mode !== 'time');
  }));

  /* ---------- toasts ---------- */
  function toast(title, body, kind) {
    const t = h('div', 'toast ' + (kind || ''));
    t.append(h('b', '', title), h('span', '', body));
    $('toasts').prepend(t);
    setTimeout(() => t.remove(), kind === 'alarm' ? 12000 : 5000);
  }

  /* ---------- alarm sound: loud, repeating until stopped ---------- */
  let ac, master, ringTimer = null;
  function audio() {
    if (!ac) {
      ac = new (window.AudioContext || window.webkitAudioContext)();
      const comp = ac.createDynamicsCompressor();
      master = ac.createGain(); master.gain.value = 1;
      master.connect(comp); comp.connect(ac.destination);
    }
    if (ac.state === 'suspended') ac.resume();
    return ac;
  }
  function tone(t, dur, freq) {
    const o = ac.createOscillator(), g = ac.createGain();
    o.type = 'square'; o.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.55, t + 0.008);
    g.gain.setValueAtTime(0.55, t + dur - 0.015);
    g.gain.linearRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(master);
    o.start(t); o.stop(t + dur + 0.02);
  }
  // "beep-beep-beep-beep ... pause", about 1.6 s per cycle, repeated forever.
  function cycle() {
    const t0 = audio().currentTime + 0.05;
    for (let i = 0; i < 4; i++) { tone(t0 + i * 0.2, 0.13, 1900); tone(t0 + 0.9 + i * 0.12, 0.08, 2350); }
  }
  function startRing() { if (ringTimer) return; cycle(); ringTimer = setInterval(cycle, 1600); }
  function stopRing() { clearInterval(ringTimer); ringTimer = null; }
  $('test-sound').addEventListener('click', () => { cycle(); setTimeout(cycle, 1600); });
  document.addEventListener('click', () => { if (ac && ac.state === 'suspended') ac.resume(); });

  /* ---------- alarms list ---------- */
  let sig = '', booted = false, prev = {}, titleTimer = null;
  const ringingNow = () => Object.values(prev).filter(a => a.status === 'ringing');

  function setRinging(list) {
    const on = list.length > 0;
    $('ring').classList.toggle('hidden', !on);
    if (on) {
      $('ring-label').textContent = list.map(a => a.label).join(', ');
      $('ring-meta').textContent = list.map(a => `process PID ${a.pid}`).join(' · ');
      startRing();
      $('ring-hint').classList.toggle('hidden', !ac || ac.state === 'running');
      if (!titleTimer) { let f = 0; titleTimer = setInterval(() => { document.title = (f++ % 2 ? '' : 'ALARM: ') + list[0].label; }, 700); }
    } else {
      stopRing();
      if (titleTimer) { clearInterval(titleTimer); titleTimer = null; document.title = 'Alarm Clock System'; }
    }
  }
  $('ring-stop').addEventListener('click', async () => {
    stopRing();
    await Promise.all(ringingNow().map(a => post(`/api/alarms/${a.id}/dismiss`)));
    setTimeout(refresh, 300);
  });

  function renderList(alarms) {
    const list = $('alarm-list');
    list.innerHTML = '';
    if (!alarms.length) { list.append(h('li', 'empty', 'No alarms yet. Set one above and watch its process below.')); return; }
    for (const a of alarms) {
      const li = h('li', 'alarm-item status-' + a.status);
      const main = h('div');
      main.append(h('span', 'alarm-label', a.label));
      const meta = h('span', 'alarm-meta', `${fmtClock(a.trigger_at)} · pid ${a.pid}`);
      main.append(meta);
      if (a.status === 'active') { const cd = h('span', 'alarm-meta cd'); cd.dataset.t = a.trigger_at; main.append(cd); }
      const right = h('div', 'right');
      right.append(h('span', 'badge ' + a.status, a.status === 'triggered' ? 'done' : a.status));
      if (a.status === 'active' || a.status === 'ringing') {
        const b = h('button', 'mini' + (a.status === 'ringing' ? ' stop' : ''), a.status === 'ringing' ? 'Stop' : 'Cancel');
        b.addEventListener('click', async () => { await post(`/api/alarms/${a.id}/${a.status === 'ringing' ? 'dismiss' : 'cancel'}`); setTimeout(refresh, 300); });
        right.append(b);
      }
      li.append(main, right);
      list.append(li);
    }
  }
  function updateCountdowns() {
    document.querySelectorAll('.cd').forEach(e => {
      const s = Math.max(0, +e.dataset.t - Math.floor(Date.now() / 1000));
      e.textContent = (s >= 3600 ? Math.floor(s / 3600) + 'h ' : '') + (s >= 60 ? Math.floor(s % 3600 / 60) + 'm ' : '') + (s % 60) + 's left';
    });
  }

  async function refresh() {
    let alarms;
    try { alarms = await (await fetch('/api/alarms')).json(); } catch (e) { return; }
    const s = JSON.stringify(alarms.map(a => [a.id, a.status]));
    if (s !== sig) { sig = s; renderList(alarms); }
    updateCountdowns();
    for (const a of alarms) {
      const was = prev[a.id] && prev[a.id].status;
      if (booted && was === 'active' && a.status === 'ringing') toast('Alarm triggered', `${a.label} · PID ${a.pid}`, 'alarm');
      if (booted && was === 'ringing' && a.status === 'triggered') toast('Alarm stopped', a.label, 'ok');
      if (booted && was === 'active' && a.status === 'cancelled') toast('Alarm cancelled', a.label);
      if (!prev[a.id] && booted && a.status === 'active') toast('Alarm set', `${a.label} · PID ${a.pid}`);
    }
    prev = Object.fromEntries(alarms.map(a => [a.id, a]));
    setRinging(ringingNow());
    if (!booted) {
      for (const a of alarms) if (a.pid && (a.status === 'active' || a.status === 'ringing')) chipFor({ pid: a.pid, alarm_id: a.id }, a.label, 'WAITING', 'q-wait');
      booted = true;
    }
  }
  setInterval(refresh, 1000);

  $('clear-btn').addEventListener('click', async () => { await post('/api/alarms/clear'); sig = ''; refresh(); });
  $('alarm-form').addEventListener('submit', async e => {
    e.preventDefault(); audio(); // user gesture: unlocks sound for later
    const err = $('form-error'); err.textContent = '';
    const label = $('label').value.trim() || 'Alarm';
    let secs;
    if (mode === 'delay') secs = (+$('delay-h').value || 0) * 3600 + (+$('delay-m').value || 0) * 60 + (+$('delay-s').value || 0);
    else {
      const v = $('target-time').value; if (!v) { err.textContent = 'Pick a time.'; return; }
      const [hh, mm, ss] = v.split(':').map(Number), n = new Date(), t = new Date(n.getFullYear(), n.getMonth(), n.getDate(), hh, mm, ss || 0);
      if (t <= n) t.setDate(t.getDate() + 1);
      secs = Math.round((t - n) / 1000);
    }
    if (secs < 1) { err.textContent = 'Alarm must be at least 1 second in the future.'; return; }
    try {
      const r = await fetch('/api/alarms', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ label, delay_seconds: secs }) });
      if (!r.ok) { err.textContent = (await r.json().catch(() => ({}))).error || 'Could not create alarm.'; return; }
      $('label').value = ''; refresh();
    } catch (x) { err.textContent = 'Could not reach the server.'; }
  });

  /* ---------- scheduler view ---------- */
  const chips = {}; // pid -> element
  const LANE = { NEW: 'q-new', WAIT: 'q-wait', READY: 'q-ready', EXIT: 'q-exit' };
  const DWELL = { NEW: 800, START: 1000, WAIT: 900, READY: 1400, RUNNING: 2200, NOTIFY: 1200, DISMISS: 1000, CANCEL: 1000, EXIT: 1200 };
  const labelOf = id => (prev[id] && prev[id].label) || 'alarm';
  let ncpu = 0;

  function chipFor(e, label, state, laneId) {
    let c = chips[e.pid];
    if (!c) { c = h('div', 'chip'); c.append(h('b'), h('span')); chips[e.pid] = c; $(laneId).append(c); c.animate([{ opacity: 0, transform: 'scale(.8)' }, { opacity: 1, transform: 'none' }], 300); }
    c.firstChild.textContent = 'PID ' + e.pid; c.lastChild.textContent = label; c.className = 'chip s-' + state;
    return c;
  }
  function moveChip(c, dest) {
    if (c.parentNode === dest) return;
    const a = c.getBoundingClientRect(); dest.append(c); const b = c.getBoundingClientRect();
    c.animate([{ transform: `translate(${a.left - b.left}px,${a.top - b.top}px)` }, { transform: 'none' }], { duration: 650, easing: 'cubic-bezier(.2,.8,.2,1)' });
  }
  function laneEl(e) {
    if (e.state === 'RUNNING') { const t = document.querySelector(`.core[data-cpu="${e.cpu}"] .slot`) || document.querySelector('.core .slot'); return t || $('q-ready'); }
    return $(LANE[e.type] || 'q-wait');
  }
  function apply(e) {
    const c = chipFor(e, labelOf(e.alarm_id), e.state, e.state === 'RUNNING' ? 'q-ready' : (LANE[e.type] || 'q-wait'));
    if (e.type !== 'NOTIFY') moveChip(c, laneEl(e));
    c.className = 'chip s-' + e.state;
    document.querySelectorAll('.core').forEach(k => k.classList.toggle('busy', !!k.querySelector('.chip')));
    if (e.type === 'EXIT') setTimeout(() => { c.remove(); delete chips[e.pid]; }, 6000);
    const log = $('log'), first = log.querySelector('.log-empty'); if (first) first.remove();
    const ln = h('div', 'ln');
    ln.append(h('span', 't', fmtT(e.ts_us / 1000)), h('span', 's ' + e.state, e.state), h('span', '', 'pid ' + e.pid + (e.cpu >= 0 ? ' cpu' + e.cpu : '')), h('span', '', e.detail));
    log.append(ln); log.scrollTop = log.scrollHeight;
    while (log.children.length > 200) log.firstChild.remove();
  }

  let lastId = null; const queue = []; let nextAt = 0;
  async function pollEvents() {
    try {
      const d = await (await fetch('/api/events?after=' + (lastId === null ? -1 : lastId))).json();
      if (lastId === null) lastId = d.last;
      else { for (const e of d.events) { queue.push(e); lastId = e.id; } }
    } catch (x) { /* retry next tick */ }
  }
  setInterval(pollEvents, 400);
  setInterval(() => {
    const now = Date.now();
    if (queue.length && now >= nextAt) {
      const e = queue.shift(); apply(e);
      nextAt = now + ($('slowmo').checked ? DWELL[e.type] || 800 : 100);
    }
  }, 100);

  /* ---------- live /proc snapshot ---------- */
  const STATE = { R: 'Running', S: 'Waiting', D: 'Disk wait', I: 'Idle', Z: 'Zombie', T: 'Stopped' };
  function buildCores(n) {
    ncpu = n; const box = $('cores'); box.innerHTML = '';
    for (let i = 0; i < n; i++) {
      const k = h('div', 'core'); k.dataset.cpu = i;
      const top = h('div', 'core-h'); top.append(h('b', '', 'CPU ' + i), h('span', 'pct', '0%'));
      const bar = h('div', 'bar'); bar.append(h('i'));
      k.append(top, bar, h('div', 'now', 'idle'), h('div', 'slot')); box.append(k);
    }
    Object.values(chips).forEach(c => { if (c.parentNode && c.parentNode.id === 'q-ready' && c.classList.contains('s-RUNNING')) moveChip(c, document.querySelector('.slot')); });
  }
  async function pollSystem() {
    let d; try { d = await (await fetch('/api/system')).json(); } catch (e) { return; }
    if (d.ncpu !== ncpu) buildCores(d.ncpu);
    const now = {};
    d.procs.forEach(p => { if (p.state === 'R') (now[p.cpu] = now[p.cpu] || []).push(`${p.name}(${p.pid})`); });
    d.cores.forEach(c => {
      const k = document.querySelector(`.core[data-cpu="${c.id}"]`); if (!k) return;
      k.querySelector('.bar i').style.width = c.usage + '%'; k.querySelector('.pct').textContent = Math.round(c.usage) + '%';
      k.querySelector('.now').textContent = now[c.id] ? now[c.id].join(' ') : 'idle';
    });
    const st = $('stats'); st.innerHTML = '';
    [['Load', d.load.map(x => x.toFixed(2)).join(' ')], ['Processes', d.counts.total], ['Running', d.counts.running], ['Sleeping', d.counts.sleeping]].forEach(([k, v]) => { const s = h('div', 'stat', k); s.append(h('b', '', v)); st.append(s); });
    const tb = document.querySelector('#procs tbody'); tb.innerHTML = '';
    for (const p of d.procs) {
      const tr = h('tr', p.kind), name = p.kind === 'server' ? 'alarm_server (server)' : p.kind === 'worker' ? `alarm worker: ${labelOf(alarmOfPid(p.pid))}` : p.name;
      const stc = h('td'); stc.append(h('span', 'st ' + p.state, STATE[p.state] || p.state)); if (p.wchan) stc.append(h('span', 'wc', p.wchan));
      tr.append(h('td', 'm', p.pid), h('td', '', name), stc, h('td', 'm', 'CPU ' + p.cpu), h('td', 'm', p.cpu_ms + ' ms'), h('td', 'm', `${p.vol} voluntary / ${p.invol} forced`));
      tb.append(tr);
    }
  }
  const alarmOfPid = pid => (Object.values(prev).find(a => a.pid === pid) || {}).id;
  setInterval(pollSystem, 600); pollSystem();
  refresh(); pollEvents();
})();
