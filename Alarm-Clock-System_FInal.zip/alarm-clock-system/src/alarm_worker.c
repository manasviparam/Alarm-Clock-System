#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <time.h>
#include <sched.h>
#include <sys/wait.h>
#include "alarm_worker.h"
#include "db.h"

/* Handlers only set flags / take a timestamp (async-signal-safe). */
static volatile sig_atomic_t g_fired = 0, g_cancelled = 0, g_dismissed = 0;
static volatile long long g_sig_us = 0;

static long long now_us(void) {
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    return (long long)ts.tv_sec * 1000000LL + ts.tv_nsec / 1000;
}

static void on_sigalrm(int s) { (void)s; g_sig_us = now_us(); g_fired = 1; }
static void on_sigusr1(int s) { (void)s; g_cancelled = 1; }
static void on_sigusr2(int s) { (void)s; g_dismissed = 1; }

/* /proc/self/schedstat: "<ns on cpu> <ns waiting on run queue> <timeslices>".
 * Returns run-queue wait in ns, or -1 if the kernel doesn't expose it. */
static long long runqueue_wait_ns(void) {
    long long on_cpu, wait; long slices;
    FILE *f = fopen("/proc/self/schedstat", "r");
    if (!f) return -1;
    int n = fscanf(f, "%lld %lld %ld", &on_cpu, &wait, &slices);
    fclose(f);
    return n == 3 ? wait : -1;
}

/* Linux desktop notification via notify-send, including the process id. */
static int send_linux_notification(const char *label, long long id, int cpu,
                                   long long lat_us, long long rq_us) {
    char title[320], body[512], runtime[64];
    snprintf(title, sizeof(title), "ALARM TRIGGERED: %s", label);
    snprintf(body, sizeof(body),
             "PID: %d   (parent PID: %d)\nAlarm ID: %lld\nRan on CPU core: %d\n"
             "State path: WAITING -> READY -> RUNNING\nRun-queue wait: %lld us   Timer latency: %lld us",
             (int)getpid(), (int)getppid(), id, cpu, rq_us, lat_us);
    if (!getenv("DBUS_SESSION_BUS_ADDRESS")) {
        snprintf(runtime, sizeof(runtime), "unix:path=/run/user/%d/bus", (int)getuid());
        setenv("DBUS_SESSION_BUS_ADDRESS", runtime, 0);
    }
    pid_t p = fork();
    if (p < 0) return -1;
    if (p == 0) {
        freopen("/dev/null", "w", stderr);
        execlp("notify-send", "notify-send", "-u", "critical", "-t", "0",
               "-a", "Alarm Clock System", "-i", "appointment-soon", title, body, (char *)NULL);
        _exit(127);
    }
    int st = 0;
    waitpid(p, &st, 0);
    return (WIFEXITED(st) && WEXITSTATUS(st) == 0) ? 0 : -1;
}

static void ev(sqlite3 *db, long long id, long long ts, const char *type,
               const char *state, int cpu, const char *detail) {
    db_add_event(db, id, (int)getpid(), ts, type, state, cpu, detail);
}

void run_alarm_worker(const char *db_path, long long alarm_id, int delay_seconds,
                      const char *label, long long fork_us) {
    sqlite3 *db = db_open(db_path);
    char d[400];
    if (!label) label = "";

    /* The server's SIGCHLD reaper is inherited across fork(); reset it so
     * waitpid() on our notify-send child works. */
    signal(SIGCHLD, SIG_DFL);

    snprintf(d, sizeof(d), "fork() created this process (parent pid %d)", (int)getppid());
    ev(db, alarm_id, fork_us, "NEW", "NEW", -1, d);
    ev(db, alarm_id, 0, "START", "RUNNING", sched_getcpu(),
       "First time on a CPU: installing SIGALRM/SIGUSR1/SIGUSR2 handlers, arming alarm()");

    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sigemptyset(&sa.sa_mask);
    sa.sa_handler = on_sigalrm; sigaction(SIGALRM, &sa, NULL);
    sa.sa_handler = on_sigusr1; sigaction(SIGUSR1, &sa, NULL);
    sa.sa_handler = on_sigusr2; sigaction(SIGUSR2, &sa, NULL);

    sigset_t block, orig;
    sigemptyset(&block);
    sigaddset(&block, SIGALRM); sigaddset(&block, SIGUSR1); sigaddset(&block, SIGUSR2);
    sigprocmask(SIG_BLOCK, &block, &orig);

    if (delay_seconds < 1) delay_seconds = 1;
    long long expected_us = now_us() + (long long)delay_seconds * 1000000LL;
    alarm((unsigned int)delay_seconds);

    long long rq_before = runqueue_wait_ns();
    snprintf(d, sizeof(d), "sigsuspend(): blocked, removed from the run queue, using 0%% CPU until SIGALRM in %ds", delay_seconds);
    ev(db, alarm_id, 0, "WAIT", "WAITING", sched_getcpu(), d);

    while (!g_fired && !g_cancelled) sigsuspend(&orig);

    if (g_cancelled && !g_fired) {
        alarm(0);
        db_mark_cancelled(db, alarm_id);
        printf("[alarm-worker pid=%d] alarm \"%s\" (id=%lld) cancelled.\n", (int)getpid(), label, alarm_id);
        fflush(stdout);
        ev(db, alarm_id, 0, "CANCEL", "RUNNING", sched_getcpu(), "SIGUSR1 received: alarm cancelled before it fired");
        ev(db, alarm_id, 0, "EXIT", "EXITED", sched_getcpu(), "exit(0): process terminated, parent reaps it via SIGCHLD");
        db_close(db);
        exit(0);
    }

    /* ---- SIGALRM fired: WAITING -> READY -> RUNNING ---- */
    int cpu = sched_getcpu();
    long long rq_after = runqueue_wait_ns();
    long long rq_us = (rq_before >= 0 && rq_after >= rq_before) ? (rq_after - rq_before) / 1000 : 0;
    long long lat_us = g_sig_us - expected_us;
    if (lat_us < 0) lat_us = 0;
    if (rq_us > lat_us) rq_us = lat_us;

    snprintf(d, sizeof(d), "Timer expired, SIGALRM sent: kernel moved the process from the wait queue to the run queue (timer scheduled for %lld)", expected_us / 1000000LL);
    ev(db, alarm_id, g_sig_us - rq_us, "READY", "READY", cpu, d);
    snprintf(d, sizeof(d), "Scheduler dispatched it on CPU %d after %lld us in the run queue; SIGALRM handler ran (timer latency %lld us)", cpu, rq_us, lat_us);
    ev(db, alarm_id, g_sig_us, "RUNNING", "RUNNING", cpu, d);

    db_mark_ringing(db, alarm_id);

    printf("\n[alarm-worker pid=%d] ALARM! \"%s\" (id=%lld) cpu=%d runqueue_wait=%lldus latency=%lldus\n",
           (int)getpid(), label, alarm_id, cpu, rq_us, lat_us);
    fflush(stdout);

    int nrc = send_linux_notification(label, alarm_id, cpu, lat_us, rq_us);
    ev(db, alarm_id, 0, "NOTIFY", "RUNNING", sched_getcpu(),
       nrc == 0 ? "Notification sent to the Linux desktop (notify-send) and the web UI"
                : "notify-send unavailable (install libnotify-bin); notified via terminal and web UI only");

    /* Ring until the user dismisses: block again, wake on SIGUSR2. */
    ev(db, alarm_id, 0, "WAIT", "WAITING", sched_getcpu(),
       "Ringing: blocked in sigsuspend() again, waiting for dismissal (SIGUSR2)");
    while (!g_dismissed && !g_cancelled) sigsuspend(&orig);

    ev(db, alarm_id, 0, "DISMISS", "RUNNING", sched_getcpu(), "Dismiss signal received: alarm stopped by the user");
    db_mark_triggered(db, alarm_id);
    printf("[alarm-worker pid=%d] alarm \"%s\" (id=%lld) dismissed.\n", (int)getpid(), label, alarm_id);
    fflush(stdout);
    ev(db, alarm_id, 0, "EXIT", "EXITED", sched_getcpu(), "exit(0): process terminated, parent reaps it via SIGCHLD");
    db_close(db);
    exit(0);
}
