#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <ctype.h>
#include <dirent.h>
#include <unistd.h>
#include <time.h>
#include "sysinfo.h"

#define MAXC 128
static unsigned long long prev_tot[MAXC], prev_idle[MAXC];

typedef struct { char name[32]; char state; int ppid, cpu; long cpu_ms; } pstat_t;

static void ap(char *b, size_t n, size_t *p, const char *fmt, ...) {
    if (*p >= n) return;
    va_list ap_; va_start(ap_, fmt);
    int w = vsnprintf(b + *p, n - *p, fmt, ap_);
    va_end(ap_);
    if (w > 0) *p += (size_t)w;
}

static int read_stat(int pid, pstat_t *o) {
    char path[64], line[1024];
    snprintf(path, sizeof(path), "/proc/%d/stat", pid);
    FILE *f = fopen(path, "r");
    if (!f) return -1;
    size_t n = fread(line, 1, sizeof(line) - 1, f);
    fclose(f);
    line[n] = '\0';
    char *l = strchr(line, '('), *r = strrchr(line, ')');
    if (!l || !r) return -1;
    size_t nl = (size_t)(r - l - 1);
    if (nl > sizeof(o->name) - 1) nl = sizeof(o->name) - 1;
    for (size_t i = 0; i < nl; i++) {
        unsigned char c = (unsigned char)l[1 + i];
        o->name[i] = (isalnum(c) || c == '-' || c == '_' || c == '.' || c == ':') ? (char)c : '_';
    }
    o->name[nl] = '\0';
    char *f_[48], *save = NULL, *tok = strtok_r(r + 2, " ", &save);
    int k = 0;
    while (tok && k < 48) { f_[k++] = tok; tok = strtok_r(NULL, " ", &save); }
    if (k < 37) return -1;
    o->state = f_[0][0];
    o->ppid = atoi(f_[1]);
    o->cpu_ms = (atol(f_[11]) + atol(f_[12])) * 1000L / sysconf(_SC_CLK_TCK);
    o->cpu = atoi(f_[36]);
    return 0;
}

static void ctx_switches(int pid, long *vol, long *invol) {
    char path[64], line[128];
    *vol = *invol = 0;
    snprintf(path, sizeof(path), "/proc/%d/status", pid);
    FILE *f = fopen(path, "r");
    if (!f) return;
    while (fgets(line, sizeof(line), f)) {
        if (!strncmp(line, "voluntary_ctxt_switches:", 24)) *vol = atol(line + 24);
        else if (!strncmp(line, "nonvoluntary_ctxt_switches:", 27)) *invol = atol(line + 27);
    }
    fclose(f);
}

static void wchan(int pid, char *out, size_t n) {
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/wchan", pid);
    out[0] = '\0';
    FILE *f = fopen(path, "r");
    if (f) { if (fgets(out, (int)n, f)) out[strcspn(out, "\n")] = '\0'; fclose(f); }
    if (!strcmp(out, "0")) out[0] = '\0';
    for (char *c = out; *c; c++) if (!isalnum((unsigned char)*c) && *c != '_') *c = '_';
}

static void emit_proc(char *b, size_t n, size_t *p, int *first, int pid, const pstat_t *s, const char *kind) {
    long vol, invol; char wc[48];
    ctx_switches(pid, &vol, &invol);
    wchan(pid, wc, sizeof(wc));
    ap(b, n, p, "%s{\"pid\":%d,\"ppid\":%d,\"name\":\"%s\",\"state\":\"%c\",\"cpu\":%d,\"cpu_ms\":%ld,"
       "\"vol\":%ld,\"invol\":%ld,\"wchan\":\"%s\",\"kind\":\"%s\"}",
       *first ? "" : ",", pid, s->ppid, s->name, s->state, s->cpu, s->cpu_ms, vol, invol, wc, kind);
    *first = 0;
}

int sysinfo_json(const int *pids, int npids, char *buf, size_t buflen) {
    size_t p = 0;
    struct timespec ts; clock_gettime(CLOCK_REALTIME, &ts);
    int ncpu = (int)sysconf(_SC_NPROCESSORS_ONLN);
    if (ncpu < 1) ncpu = 1;
    if (ncpu > MAXC) ncpu = MAXC;
    ap(buf, buflen, &p, "{\"ts_ms\":%lld,\"ncpu\":%d,", (long long)ts.tv_sec * 1000LL + ts.tv_nsec / 1000000, ncpu);

    double l1 = 0, l5 = 0, l15 = 0;
    FILE *f = fopen("/proc/loadavg", "r");
    if (f) { if (fscanf(f, "%lf %lf %lf", &l1, &l5, &l15) != 3) l1 = l5 = l15 = 0; fclose(f); }
    ap(buf, buflen, &p, "\"load\":[%.2f,%.2f,%.2f],\"cores\":[", l1, l5, l15);

    /* Per-core usage = busy share of jiffies since the previous snapshot. */
    f = fopen("/proc/stat", "r");
    char line[512]; int emitted = 0;
    while (f && fgets(line, sizeof(line), f)) {
        int id;
        unsigned long long u, ni, sy, id_, io, ir, so, st;
        if (strncmp(line, "cpu", 3) || !isdigit((unsigned char)line[3])) continue;
        if (sscanf(line, "cpu%d %llu %llu %llu %llu %llu %llu %llu %llu", &id, &u, &ni, &sy, &id_, &io, &ir, &so, &st) < 9 || id >= MAXC) continue;
        unsigned long long tot = u + ni + sy + id_ + io + ir + so + st, idle = id_ + io;
        unsigned long long dt = tot - prev_tot[id], di = idle - prev_idle[id];
        double usage = (prev_tot[id] && dt) ? 100.0 * (double)(dt - di) / (double)dt : 0.0;
        prev_tot[id] = tot; prev_idle[id] = idle;
        ap(buf, buflen, &p, "%s{\"id\":%d,\"usage\":%.1f}", emitted++ ? "," : "", id, usage);
    }
    if (f) fclose(f);
    ap(buf, buflen, &p, "],");

    /* Count every process by state; remember a few runnable system tasks. */
    int running = 0, sleeping = 0, other = 0, total = 0, nsys = 0;
    int sys_pid[6]; pstat_t sys_st[6];
    int self = (int)getpid();
    DIR *d = opendir("/proc");
    struct dirent *e;
    while (d && (e = readdir(d))) {
        if (!isdigit((unsigned char)e->d_name[0])) continue;
        int pid = atoi(e->d_name);
        pstat_t s;
        if (read_stat(pid, &s) != 0) continue;
        total++;
        if (s.state == 'R') running++;
        else if (s.state == 'S' || s.state == 'D' || s.state == 'I') sleeping++;
        else other++;
        int tracked = (pid == self);
        for (int i = 0; i < npids; i++) if (pids[i] == pid) tracked = 1;
        if (s.state == 'R' && !tracked && nsys < 6) { sys_pid[nsys] = pid; sys_st[nsys++] = s; }
    }
    if (d) closedir(d);
    ap(buf, buflen, &p, "\"counts\":{\"total\":%d,\"running\":%d,\"sleeping\":%d,\"other\":%d},\"procs\":[", total, running, sleeping, other);

    int first = 1; pstat_t s;
    if (read_stat(self, &s) == 0) emit_proc(buf, buflen, &p, &first, self, &s, "server");
    for (int i = 0; i < npids; i++)
        if (read_stat(pids[i], &s) == 0) emit_proc(buf, buflen, &p, &first, pids[i], &s, "worker");
    for (int i = 0; i < nsys; i++) emit_proc(buf, buflen, &p, &first, sys_pid[i], &sys_st[i], "system");
    ap(buf, buflen, &p, "]}");
    return p < buflen ? (int)p : -1;
}
