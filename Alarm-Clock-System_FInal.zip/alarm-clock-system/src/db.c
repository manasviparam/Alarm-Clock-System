#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <errno.h>
#include "db.h"

static const char *CREATE_TABLE_SQL =
    "CREATE TABLE IF NOT EXISTS alarms ("
    "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
    "  label TEXT NOT NULL,"
    "  delay_seconds INTEGER NOT NULL,"
    "  created_at INTEGER NOT NULL,"
    "  trigger_at INTEGER NOT NULL,"
    "  status TEXT NOT NULL DEFAULT 'active'," /* active | triggered | cancelled */
    "  pid INTEGER NOT NULL DEFAULT 0"
    ");";

sqlite3 *db_open(const char *path) {
    sqlite3 *db = NULL;
    if (sqlite3_open(path, &db) != SQLITE_OK) {
        fprintf(stderr, "db_open: %s\n", sqlite3_errmsg(db));
        return NULL;
    }

    /* WAL mode + a busy timeout let the server process and the short-lived
     * per-alarm worker processes touch the same file concurrently without
     * "database is locked" errors. */
    sqlite3_busy_timeout(db, 3000);
    char *errmsg = NULL;
    sqlite3_exec(db, "PRAGMA journal_mode=WAL;", NULL, NULL, &errmsg);
    if (errmsg) { sqlite3_free(errmsg); errmsg = NULL; }

    if (sqlite3_exec(db, CREATE_TABLE_SQL, NULL, NULL, &errmsg) != SQLITE_OK) {
        fprintf(stderr, "db_open: create table failed: %s\n", errmsg);
        sqlite3_free(errmsg);
        sqlite3_close(db);
        return NULL;
    }
    if (sqlite3_exec(db,
        "CREATE TABLE IF NOT EXISTS events ("
        " id INTEGER PRIMARY KEY AUTOINCREMENT, alarm_id INTEGER NOT NULL,"
        " pid INTEGER NOT NULL, ts_us INTEGER NOT NULL, type TEXT NOT NULL,"
        " state TEXT NOT NULL, cpu INTEGER NOT NULL, detail TEXT NOT NULL);",
        NULL, NULL, &errmsg) != SQLITE_OK) {
        fprintf(stderr, "db_open: events table failed: %s\n", errmsg);
        sqlite3_free(errmsg);
    }
    return db;
}

void db_close(sqlite3 *db) {
    if (db) sqlite3_close(db);
}

long long db_insert_alarm(sqlite3 *db, const char *label,
                           int delay_seconds, time_t trigger_at) {
    const char *sql =
        "INSERT INTO alarms (label, delay_seconds, created_at, trigger_at, status, pid) "
        "VALUES (?, ?, strftime('%s','now'), ?, 'active', 0);";
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) != SQLITE_OK) return -1;

    sqlite3_bind_text(stmt, 1, label, -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 2, delay_seconds);
    sqlite3_bind_int64(stmt, 3, (sqlite3_int64)trigger_at);

    long long id = -1;
    if (sqlite3_step(stmt) == SQLITE_DONE) {
        id = sqlite3_last_insert_rowid(db);
    }
    sqlite3_finalize(stmt);
    return id;
}

int db_set_pid(sqlite3 *db, long long id, pid_t pid) {
    const char *sql = "UPDATE alarms SET pid = ? WHERE id = ?;";
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) != SQLITE_OK) return -1;
    sqlite3_bind_int(stmt, 1, (int)pid);
    sqlite3_bind_int64(stmt, 2, id);
    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return (rc == SQLITE_DONE) ? 0 : -1;
}

static int mark_status(sqlite3 *db, long long id, const char *from, const char *new_status) {
    const char *sql = "UPDATE alarms SET status = ? WHERE id = ? AND status = ?;";
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) != SQLITE_OK) return -1;
    sqlite3_bind_text(stmt, 1, new_status, -1, SQLITE_STATIC);
    sqlite3_bind_int64(stmt, 2, id);
    sqlite3_bind_text(stmt, 3, from, -1, SQLITE_STATIC);
    int rc = sqlite3_step(stmt);
    int changed = sqlite3_changes(db);
    sqlite3_finalize(stmt);
    return (rc == SQLITE_DONE && changed > 0) ? 0 : -1;
}

int db_mark_ringing(sqlite3 *db, long long id)   { return mark_status(db, id, "active", "ringing"); }
int db_mark_triggered(sqlite3 *db, long long id) { return mark_status(db, id, "ringing", "triggered"); }
int db_mark_cancelled(sqlite3 *db, long long id) { return mark_status(db, id, "active", "cancelled"); }

int db_get_pid_status(sqlite3 *db, long long id, pid_t *pid, char *status_out, size_t status_len) {
    const char *sql = "SELECT pid, status FROM alarms WHERE id = ?;";
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) != SQLITE_OK) return -1;
    sqlite3_bind_int64(stmt, 1, id);

    int rc = -1;
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        if (pid) *pid = (pid_t)sqlite3_column_int(stmt, 0);
        const unsigned char *s = sqlite3_column_text(stmt, 1);
        if (status_out && s) {
            snprintf(status_out, status_len, "%s", (const char *)s);
        }
        rc = 0;
    }
    sqlite3_finalize(stmt);
    return rc;
}

/* Very small JSON string escaper: handles the characters that can
 * plausibly show up in a user-typed alarm label. */
static void json_escape_append(char *buf, size_t buflen, size_t *pos, const char *s) {
    for (; *s && *pos < buflen - 1; s++) {
        unsigned char c = (unsigned char)*s;
        if (c == '"' || c == '\\') {
            if (*pos + 2 >= buflen) break;
            buf[(*pos)++] = '\\';
            buf[(*pos)++] = c;
        } else if (c == '\n') {
            if (*pos + 2 >= buflen) break;
            buf[(*pos)++] = '\\';
            buf[(*pos)++] = 'n';
        } else if (c < 0x20) {
            /* skip other control chars */
        } else {
            buf[(*pos)++] = c;
        }
    }
}

int db_alarms_to_json(sqlite3 *db, char *buf, size_t buflen) {
    const char *sql =
        "SELECT id, label, delay_seconds, created_at, trigger_at, status, pid "
        "FROM alarms ORDER BY id DESC;";
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) != SQLITE_OK) return -1;

    size_t pos = 0;
    buf[pos++] = '[';
    int first = 1;

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        if (!first) buf[pos++] = ',';
        first = 0;

        long long id = sqlite3_column_int64(stmt, 0);
        const unsigned char *label = sqlite3_column_text(stmt, 1);
        int delay_seconds = sqlite3_column_int(stmt, 2);
        long long created_at = sqlite3_column_int64(stmt, 3);
        long long trigger_at = sqlite3_column_int64(stmt, 4);
        const unsigned char *status = sqlite3_column_text(stmt, 5);
        int pid = sqlite3_column_int(stmt, 6);

        char row[768];
        size_t rpos = 0;
        rpos += snprintf(row, sizeof(row),
            "{\"id\":%lld,\"label\":\"", id);
        json_escape_append(row, sizeof(row), &rpos, label ? (const char *)label : "");
        rpos += snprintf(row + rpos, sizeof(row) - rpos,
            "\",\"delay_seconds\":%d,\"created_at\":%lld,\"trigger_at\":%lld,"
            "\"status\":\"%s\",\"pid\":%d}",
            delay_seconds, created_at, trigger_at,
            status ? (const char *)status : "unknown", pid);

        if (pos + rpos >= buflen - 2) { sqlite3_finalize(stmt); return -1; }
        memcpy(buf + pos, row, rpos);
        pos += rpos;
    }

    buf[pos++] = ']';
    buf[pos] = '\0';
    sqlite3_finalize(stmt);
    return (int)pos;
}

int db_clear_finished(sqlite3 *db) {
    char *errmsg = NULL;
    int rc = sqlite3_exec(db, "DELETE FROM alarms WHERE status NOT IN ('active','ringing');"
        "DELETE FROM events WHERE alarm_id NOT IN (SELECT id FROM alarms);", NULL, NULL, &errmsg);
    if (errmsg) { fprintf(stderr, "db_clear_finished: %s\n", errmsg); sqlite3_free(errmsg); }
    return (rc == SQLITE_OK) ? 0 : -1;
}

int db_add_event(sqlite3 *db, long long alarm_id, int pid, long long ts_us,
                 const char *type, const char *state, int cpu, const char *detail) {
    if (ts_us <= 0) {
        struct timespec ts; clock_gettime(CLOCK_REALTIME, &ts);
        ts_us = (long long)ts.tv_sec * 1000000LL + ts.tv_nsec / 1000;
    }
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(db, "INSERT INTO events (alarm_id,pid,ts_us,type,state,cpu,detail) "
                               "VALUES (?,?,?,?,?,?,?);", -1, &stmt, NULL) != SQLITE_OK) return -1;
    sqlite3_bind_int64(stmt, 1, alarm_id);
    sqlite3_bind_int(stmt, 2, pid);
    sqlite3_bind_int64(stmt, 3, ts_us);
    sqlite3_bind_text(stmt, 4, type, -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 5, state, -1, SQLITE_STATIC);
    sqlite3_bind_int(stmt, 6, cpu);
    sqlite3_bind_text(stmt, 7, detail, -1, SQLITE_TRANSIENT);
    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE ? 0 : -1;
}

int db_events_to_json(sqlite3 *db, long long after, char *buf, size_t buflen) {
    long long last = 0;
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(db, "SELECT COALESCE(MAX(id),0) FROM events;", -1, &stmt, NULL) == SQLITE_OK) {
        if (sqlite3_step(stmt) == SQLITE_ROW) last = sqlite3_column_int64(stmt, 0);
        sqlite3_finalize(stmt);
    }
    size_t pos = (size_t)snprintf(buf, buflen, "{\"last\":%lld,\"events\":[", last);
    if (after >= 0) {
        if (sqlite3_prepare_v2(db, "SELECT id,alarm_id,pid,ts_us,type,state,cpu,detail FROM events "
                                   "WHERE id > ? ORDER BY id LIMIT 100;", -1, &stmt, NULL) != SQLITE_OK) return -1;
        sqlite3_bind_int64(stmt, 1, after);
        int first = 1;
        while (sqlite3_step(stmt) == SQLITE_ROW) {
            char row[768]; size_t r = 0;
            r += snprintf(row, sizeof(row), "{\"id\":%lld,\"alarm_id\":%lld,\"pid\":%d,\"ts_us\":%lld,"
                          "\"type\":\"%s\",\"state\":\"%s\",\"cpu\":%d,\"detail\":\"",
                          (long long)sqlite3_column_int64(stmt, 0), (long long)sqlite3_column_int64(stmt, 1),
                          sqlite3_column_int(stmt, 2), (long long)sqlite3_column_int64(stmt, 3),
                          sqlite3_column_text(stmt, 4), sqlite3_column_text(stmt, 5), sqlite3_column_int(stmt, 6));
            json_escape_append(row, sizeof(row) - 4, &r, (const char *)sqlite3_column_text(stmt, 7));
            r += snprintf(row + r, sizeof(row) - r, "\"}");
            if (pos + r + 4 >= buflen) break;
            if (!first) buf[pos++] = ',';
            first = 0;
            memcpy(buf + pos, row, r); pos += r;
        }
        sqlite3_finalize(stmt);
    }
    pos += (size_t)snprintf(buf + pos, buflen - pos, "]}");
    return (int)pos;
}

int db_active_pids(sqlite3 *db, int *pids, int max) {
    sqlite3_stmt *stmt; int n = 0;
    if (sqlite3_prepare_v2(db, "SELECT pid FROM alarms WHERE status IN ('active','ringing') AND pid>0;",
                           -1, &stmt, NULL) != SQLITE_OK) return 0;
    while (n < max && sqlite3_step(stmt) == SQLITE_ROW) pids[n++] = sqlite3_column_int(stmt, 0);
    sqlite3_finalize(stmt);
    return n;
}

void db_cleanup_orphans(sqlite3 *db) {
    int pids[256], n = db_active_pids(db, pids, 256);
    for (int i = 0; i < n; i++) {
        if (kill(pids[i], 0) != 0 && errno == ESRCH) {
            sqlite3_stmt *s;
            if (sqlite3_prepare_v2(db, "UPDATE alarms SET status='cancelled' WHERE pid=? AND status IN ('active','ringing');",
                                   -1, &s, NULL) == SQLITE_OK) {
                sqlite3_bind_int(s, 1, pids[i]); sqlite3_step(s); sqlite3_finalize(s);
            }
        }
    }
}
