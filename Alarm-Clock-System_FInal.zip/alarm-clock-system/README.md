# Alarm Clock System

A Linux-based alarm clock built for the "Operating Systems and Systems
Programming" scenario: **schedule an alarm for a specific time, keep doing
other work while waiting, and get notified (or cancel) when the time
comes** — with a web UI on top.

Everything, including the web server, is written in **C** and runs in user
space. No kernel modification.

## How it maps to the assignment

| Requirement | Implementation |
|---|---|
| Accept an alarm time or delay | Web form (delay or clock time) &rarr; `POST /api/alarms` |
| Create a process to manage the alarm | `fork()` — one child process per alarm, in `handle_post_alarms()` |
| Use timers/signals to generate the alarm event | `alarm(2)` timer, `SIGALRM` signal |
| Suspend the process while waiting | `sigprocmask()` + `sigsuspend(2)` (no busy-waiting) |
| Handle the alarm signal | `sigaction()` handler for `SIGALRM` in `alarm_worker.c` |
| Display a notification | Server console, a **Linux desktop notification** (`notify-send`, includes PID / CPU core / latency), and a banner + toast in the web UI |
| Cancel an active alarm | `kill(pid, SIGUSR1)`; the worker's `SIGUSR1` handler cancels it |
| Stop a ringing alarm | `kill(pid, SIGUSR2)`; the worker wakes from its second `sigsuspend()` and exits |
| Show CPU / scheduler activity | Workers log real state changes (core, timestamps, run-queue delay from `/proc/self/schedstat`); the server reads `/proc` for live state |
| Multiple alarm requests | Each alarm is an independent process; `SIGCHLD` handler reaps them (no zombies) |
| IPC between the C engine and the app | Shared SQLite database file (`db/alarms.db`) written by both the server and each worker process |
| Web frontend + backend + database | `public/` (HTML/CSS/JS) served by the same C binary; SQLite for persistence |

## Project layout

```
alarm-clock-system/
├── Makefile
├── include/            # headers
│   ├── db.h            # SQLite persistence layer
│   ├── http.h          # tiny HTTP request/response helpers
│   └── alarm_worker.h  # per-alarm child process logic
├── src/
│   ├── db.c
│   ├── http.c
│   ├── sysinfo.c       # /proc reader: per-core usage, process states, context switches
│   ├── alarm_worker.c  # fork()'d process: alarm() + SIGALRM + sigsuspend()
│   └── server.c        # main(): HTTP server + routing + fork()
├── public/              # web UI
│   ├── index.html
│   ├── style.css
│   └── app.js
└── db/                  # SQLite database file lives here at runtime
```

## Build & run (Ubuntu / Debian / WSL)

```bash
sudo apt update
sudo apt install -y build-essential libsqlite3-dev libnotify-bin   # libnotify-bin provides notify-send

cd alarm-clock-system
make
./alarm_server            # defaults: port 8080, db/alarms.db, public/
```

Then open **http://localhost:8080** in a browser.

Optional arguments: `./alarm_server <port> <db_path> <public_dir>`

To rebuild from scratch: `make clean && make`

## Using it

1. Type a label, choose **Delay** or **Clock time**, click **Set alarm**.
2. The **CPU scheduler** panel shows each alarm as a process chip moving through
   the classic states, driven by what the worker really did:
   - **New** (just `fork()`ed) -> **CPU core** (first run: installs handlers, arms `alarm()`)
   - -> **Wait queue** (`sigsuspend()`: blocked, 0% CPU)
   - on `SIGALRM`: -> **Ready queue** (runnable) -> **CPU core N** (handler runs, notification sent)
   - -> **Wait queue** again while ringing -> **CPU core** on dismiss -> **Exited**
   The event log underneath shows true timestamps, the core used, and the measured
   run-queue delay and timer latency (usually microseconds). **Slow motion** only
   stretches the animation so you can follow it; untick it for real-time playback.
   The process table is read live from `/proc` (state, last core, CPU time, context switches).
3. When an alarm fires: a red banner and toast say **Alarm triggered**, a loud
   repeating alarm sound plays **until you press Stop alarm**, and a Linux
   notification appears, for example:
   ```
   ALARM TRIGGERED: Wake up
   PID: 48213   (parent PID: 48190)
   Alarm ID: 3 ... Ran on CPU core: 2 ... Run-queue wait / Timer latency in us
   ```
   The terminal also prints a line with the PID.
4. **Cancel** an alarm before it fires, or **Stop** it while it rings. **Test sound** previews the alarm.

**Notes on notifications / sound**
- Linux notifications use `notify-send` (`sudo apt install libnotify-bin`) and need a desktop
  session; run `./alarm_server` from a terminal inside that session. Without it, the
  alarm still works and the terminal + web UI notify you. WSL has no notification daemon by default.
- Browsers only allow sound after you interact with the page; clicking **Set alarm** or
  **Test sound** once unlocks it.

For the presentation, it's worth having a second terminal open running
`ps --forest -o pid,ppid,cmd` (or `pstree -p <server_pid>`) while you create
a few alarms — you'll visibly see a new `alarm_server` child process appear
for each alarm and disappear once it fires or is cancelled.

## Notes / simplifications

- The HTTP server handles one request at a time (`accept()` in a loop) —
  plenty for a demo UI, and it keeps the code focused on the OS concepts
  rather than a threading model.
- The JSON body parser is intentionally minimal (`json_get_string` /
  `json_get_int` in `http.c`): it's built only to read the fixed
  `{"label": ..., "delay_seconds": ...}` shape this project's own frontend
  sends, not to be a general-purpose JSON parser.
- SQLite runs in WAL mode so the server process and short-lived worker
  processes can safely touch the database file concurrently.
