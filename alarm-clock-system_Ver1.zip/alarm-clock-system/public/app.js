(() => {
  const clockEl = document.getElementById('clock');
  const form = document.getElementById('alarm-form');
  const listEl = document.getElementById('alarm-list');
  const errorEl = document.getElementById('form-error');
  const clearBtn = document.getElementById('clear-btn');
  const toggleBtns = document.querySelectorAll('.toggle-btn');
  const delayFields = document.getElementById('delay-fields');
  const timeFields = document.getElementById('time-fields');

  let mode = 'delay';
  let knownStatus = {}; // id -> last seen status, to detect transitions -> triggered

  function pad(n) { return String(n).padStart(2, '0'); }

  function tickClock() {
    const now = new Date();
    clockEl.textContent = `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
  }
  setInterval(tickClock, 1000);
  tickClock();

  toggleBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      toggleBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      mode = btn.dataset.mode;
      delayFields.classList.toggle('hidden', mode !== 'delay');
      timeFields.classList.toggle('hidden', mode !== 'time');
    });
  });

  function beep() {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = 880;
      gain.gain.setValueAtTime(0.001, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.9);
      osc.connect(gain).connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.9);
      // A second, higher chirp shortly after for a classic "alarm" feel.
      setTimeout(() => {
        const ctx2 = new (window.AudioContext || window.webkitAudioContext)();
        const o2 = ctx2.createOscillator();
        const g2 = ctx2.createGain();
        o2.type = 'sine';
        o2.frequency.value = 1046;
        g2.gain.setValueAtTime(0.001, ctx2.currentTime);
        g2.gain.exponentialRampToValueAtTime(0.25, ctx2.currentTime + 0.02);
        g2.gain.exponentialRampToValueAtTime(0.001, ctx2.currentTime + 0.9);
        o2.connect(g2).connect(ctx2.destination);
        o2.start();
        o2.stop(ctx2.currentTime + 0.9);
      }, 250);
    } catch (e) { /* Web Audio not available; silently skip. */ }
  }

  function fmtRemaining(triggerAt, status) {
    if (status !== 'active') return '';
    const secs = triggerAt - Math.floor(Date.now() / 1000);
    if (secs <= 0) return 'firing...';
    const h = Math.floor(secs / 3600);
    const m = Math.floor((secs % 3600) / 60);
    const s = secs % 60;
    let out = '';
    if (h) out += `${h}h `;
    if (h || m) out += `${m}m `;
    out += `${s}s left`;
    return out;
  }

  function fmtClockTime(ts) {
    const d = new Date(ts * 1000);
    return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  }

  async function refresh() {
    let alarms;
    try {
      const res = await fetch('/api/alarms');
      alarms = await res.json();
    } catch (e) {
      return;
    }

    if (alarms.length === 0) {
      listEl.innerHTML = '<li class="empty">No alarms yet.</li>';
      knownStatus = {};
      return;
    }

    listEl.innerHTML = '';
    for (const a of alarms) {
      const justFired = knownStatus[a.id] === 'active' && a.status === 'triggered';
      knownStatus[a.id] = a.status;

      const li = document.createElement('li');
      li.className = `alarm-item status-${a.status}` + (justFired ? ' just-fired' : '');

      const main = document.createElement('div');
      main.className = 'alarm-main';
      const labelEl = document.createElement('span');
      labelEl.className = 'alarm-label';
      labelEl.textContent = a.label;
      const metaEl = document.createElement('span');
      metaEl.className = 'alarm-meta';
      const remaining = fmtRemaining(a.trigger_at, a.status);
      metaEl.textContent = `Set for ${fmtClockTime(a.trigger_at)}` + (remaining ? ` · ${remaining}` : '') + ` · pid ${a.pid}`;
      main.appendChild(labelEl);
      main.appendChild(metaEl);

      const right = document.createElement('div');
      right.style.display = 'flex';
      right.style.alignItems = 'center';
      right.style.gap = '8px';

      const badge = document.createElement('span');
      badge.className = `badge ${a.status}`;
      badge.textContent = a.status;
      right.appendChild(badge);

      if (a.status === 'active') {
        const cancelBtn = document.createElement('button');
        cancelBtn.className = 'cancel-btn';
        cancelBtn.textContent = 'Cancel';
        cancelBtn.addEventListener('click', () => cancelAlarm(a.id));
        right.appendChild(cancelBtn);
      }

      li.appendChild(main);
      li.appendChild(right);
      listEl.appendChild(li);

      if (justFired) beep();
    }
  }

  async function cancelAlarm(id) {
    try {
      await fetch(`/api/alarms/${id}/cancel`, { method: 'POST' });
    } catch (e) { /* ignore */ }
    refresh();
  }

  clearBtn.addEventListener('click', async () => {
    try {
      await fetch('/api/alarms/clear', { method: 'POST' });
    } catch (e) { /* ignore */ }
    refresh();
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    errorEl.textContent = '';

    const label = document.getElementById('label').value.trim() || 'Alarm';
    let delaySeconds;

    if (mode === 'delay') {
      const h = parseInt(document.getElementById('delay-h').value, 10) || 0;
      const m = parseInt(document.getElementById('delay-m').value, 10) || 0;
      const s = parseInt(document.getElementById('delay-s').value, 10) || 0;
      delaySeconds = h * 3600 + m * 60 + s;
    } else {
      const val = document.getElementById('target-time').value; // "HH:MM:SS" or "HH:MM"
      if (!val) { errorEl.textContent = 'Pick a time.'; return; }
      const [hh, mm, ss] = val.split(':').map(Number);
      const now = new Date();
      const target = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hh, mm, ss || 0, 0);
      if (target <= now) target.setDate(target.getDate() + 1); // rolled past today -> tomorrow
      delaySeconds = Math.round((target.getTime() - now.getTime()) / 1000);
    }

    if (!delaySeconds || delaySeconds < 1) {
      errorEl.textContent = 'Alarm must be at least 1 second in the future.';
      return;
    }

    try {
      const res = await fetch('/api/alarms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ label, delay_seconds: delaySeconds })
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        errorEl.textContent = err.error || 'Could not create alarm.';
        return;
      }
      document.getElementById('label').value = '';
      refresh();
    } catch (e) {
      errorEl.textContent = 'Could not reach the server.';
    }
  });

  refresh();
  setInterval(refresh, 1000);
})();
