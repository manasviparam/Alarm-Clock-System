#ifndef ALARM_WORKER_H
#define ALARM_WORKER_H

#include <sys/types.h>

/* Runs inside a freshly forked child process for one alarm.
 *
 * Demonstrates the required OS/Systems Programming mechanisms:
 *   - a dedicated process per alarm (the fork() that created this child)
 *   - a Linux timer (alarm(2)) to schedule the wakeup
 *   - process suspension while waiting (sigsuspend(2), not a busy loop)
 *   - signal handling: SIGALRM fires the alarm, SIGUSR1 cancels it
 *   - IPC with the server process via the shared SQLite database file
 *
 * Never returns: it always calls exit() itself once the alarm has
 * either fired or been cancelled.
 */
void run_alarm_worker(const char *db_path, long long alarm_id, int delay_seconds,
                       const char *label) __attribute__((noreturn));

#endif
