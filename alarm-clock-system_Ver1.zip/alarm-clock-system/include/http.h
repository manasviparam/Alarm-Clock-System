#ifndef HTTP_H
#define HTTP_H

#include <stddef.h>

#define HTTP_MAX_REQUEST 65536

typedef struct {
    char method[8];      /* GET, POST, DELETE, ... */
    char path[512];      /* /api/alarms/3           */
    char body[8192];     /* request body, if any    */
    size_t body_len;
} http_request_t;

/* Reads one HTTP request off a connected socket fd into `req`.
 * Returns 0 on success, -1 on error/EOF. */
int http_read_request(int fd, http_request_t *req);

/* Sends a complete HTTP response (status line + headers + body). */
void http_send_response(int fd, int status_code, const char *status_text,
                         const char *content_type, const char *body, size_t body_len);

/* Convenience wrapper for small JSON responses. */
void http_send_json(int fd, int status_code, const char *json);

/* Serves a static file from disk with a guessed Content-Type. */
void http_send_file(int fd, const char *filepath);

/* --- tiny helpers for pulling fields out of a JSON object body ---
 * These are NOT a general JSON parser: they just look for "key" and
 * read the value that follows. That's all this project's fixed,
 * self-controlled request bodies need. */
int json_get_string(const char *json, const char *key, char *out, size_t out_len);
long json_get_int(const char *json, const char *key, long default_value);

#endif
