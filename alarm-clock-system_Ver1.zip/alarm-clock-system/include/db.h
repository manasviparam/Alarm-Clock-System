#ifndef DB_H
#define DB_H

#include <sqlite3.h>
#include <time.h>

/* Opens (or creates) the SQLite database at `path` and makes sure the
 * alarms table exists. Returns a handle on success, NULL on failure. */
sqlite3 *db_open(const char *path);

void db_close(sqlite3 *db);

/* Inserts a new alarm row with status='active' and returns its id,
 * or -1 on failure. trigger_at is a unix timestamp. */
long long db_insert_alarm(sqlite3 *db, const char *label,
                           int delay_seconds, time_t trigger_at);

/* Records the pid of the worker process that owns alarm `id`. */
int db_set_pid(sqlite3 *db, long long id, pid_t pid);

/* Marks the alarm triggered, but only if it is still 'active'
 * (avoids clobbering a status set by a concurrent cancel). */
int db_mark_triggered(sqlite3 *db, long long id);

/* Marks the alarm cancelled, but only if it is still 'active'. */
int db_mark_cancelled(sqlite3 *db, long long id);

/* Looks up the pid + status for an alarm. Returns 0 on success. */
int db_get_pid_status(sqlite3 *db, long long id, pid_t *pid, char *status_out, size_t status_len);

/* Builds a JSON array of all alarms into `buf` (caller-allocated).
 * Returns the number of bytes written (excluding NUL), or -1 if it
 * didn't fit. */
int db_alarms_to_json(sqlite3 *db, char *buf, size_t buflen);

/* Deletes every alarm that is no longer active (triggered/cancelled). */
int db_clear_finished(sqlite3 *db);

#endif
