# Alarm Clock System

A Linux-based alarm clock built for the "Operating Systems and Systems
Programming" scenario: **schedule an alarm for a specific time, keep doing
other work while waiting, and get notified (or cancel) when the time
comes** — with a web UI on top.

Everything, including the web server, is written in **C** and runs in user
space. No kernel modification.

## How it maps to the assignment

| Requirement | Implementation |
|---|---|
| Accept an alarm time or delay | Web form (delay or clock time) &rarr; `POST /api/alarms` |
| Create a process to manage the alarm | `fork()` — one child process per alarm, in `handle_post_alarms()` |
| Use timers/signals to generate the alarm event | `alarm(2)` timer, `SIGALRM` signal |
| Suspend the process while waiting | `sigprocmask()` + `sigsuspend(2)` (no busy-waiting) |
| Handle the alarm signal | `sigaction()` handler for `SIGALRM` in `alarm_worker.c` |
| Display a notification | Printed to the server console **and** shown live in the web UI (with a beep) |
| Cancel an active alarm | `kill(pid, SIGUSR1)`; the worker's `SIGUSR1` handler cancels it |
| Multiple alarm requests | Each alarm is an independent process; `SIGCHLD` handler reaps them (no zombies) |
| IPC between the C engine and the app | Shared SQLite database file (`db/alarms.db`) written by both the server and each worker process |
| Web frontend + backend + database | `public/` (HTML/CSS/JS) served by the same C binary; SQLite for persistence |

## Project layout

```
alarm-clock-system/
├── Makefile
├── include/            # headers
│   ├── db.h            # SQLite persistence layer
│   ├── http.h          # tiny HTTP request/response helpers
│   └── alarm_worker.h  # per-alarm child process logic
├── src/
│   ├── db.c
│   ├── http.c
│   ├── alarm_worker.c  # fork()'d process: alarm() + SIGALRM + sigsuspend()
│   └── server.c        # main(): HTTP server + routing + fork()
├── public/              # web UI
│   ├── index.html
│   ├── style.css
│   └── app.js
└── db/                  # SQLite database file lives here at runtime
```

## Build & run (Ubuntu / Debian / WSL)

```bash
sudo apt update
sudo apt install -y build-essential libsqlite3-dev

cd alarm-clock-system
make
./alarm_server            # defaults: port 8080, db/alarms.db, public/
```

Then open **http://localhost:8080** in a browser.

Optional arguments: `./alarm_server <port> <db_path> <public_dir>`

To rebuild from scratch: `make clean && make`

## Using it

1. Type a label, choose **"In..."** (a delay) or **"At clock time"**, and
   click **Set Alarm**.
2. The alarm appears in the list immediately with a live countdown and its
   worker process's PID.
3. When it fires: the card flashes, a beep plays in the browser, and the
   server's terminal prints something like:
   ```
   [alarm-worker pid=48213] ⏰ ALARM! "Wake up" (id=3) is going off now.
   ```
4. Click **Cancel** on any still-active alarm to stop it before it fires.
5. **Clear finished** removes triggered/cancelled entries from the list.

For the presentation, it's worth having a second terminal open running
`ps --forest -o pid,ppid,cmd` (or `pstree -p <server_pid>`) while you create
a few alarms — you'll visibly see a new `alarm_server` child process appear
for each alarm and disappear once it fires or is cancelled.

## Notes / simplifications

- The HTTP server handles one request at a time (`accept()` in a loop) —
  plenty for a demo UI, and it keeps the code focused on the OS concepts
  rather than a threading model.
- The JSON body parser is intentionally minimal (`json_get_string` /
  `json_get_int` in `http.c`): it's built only to read the fixed
  `{"label": ..., "delay_seconds": ...}` shape this project's own frontend
  sends, not to be a general-purpose JSON parser.
- SQLite runs in WAL mode so the server process and short-lived worker
  processes can safely touch the database file concurrently.
