#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <time.h>
#include "alarm_worker.h"
#include "db.h"

/* Signal handlers must only touch async-signal-safe state: set a flag
 * and return. All the real work (DB update, printing) happens after
 * sigsuspend() wakes back up in run_alarm_worker(). */
static volatile sig_atomic_t g_fired = 0;
static volatile sig_atomic_t g_cancelled = 0;

static void on_sigalrm(int sig) { (void)sig; g_fired = 1; }
static void on_sigusr1(int sig) { (void)sig; g_cancelled = 1; }

void run_alarm_worker(const char *db_path, long long alarm_id, int delay_seconds,
                       const char *label) {
    /* Each process gets its own SQLite connection; sharing a handle
     * across fork() is not safe, and POSIX file locks are per-process
     * anyway, so a fresh connection is the correct approach. */
    sqlite3 *db = db_open(db_path);

    struct sigaction sa_alrm, sa_usr1;
    memset(&sa_alrm, 0, sizeof(sa_alrm));
    memset(&sa_usr1, 0, sizeof(sa_usr1));
    sa_alrm.sa_handler = on_sigalrm;
    sa_usr1.sa_handler = on_sigusr1;
    sigemptyset(&sa_alrm.sa_mask);
    sigemptyset(&sa_usr1.sa_mask);
    sigaction(SIGALRM, &sa_alrm, NULL);
    sigaction(SIGUSR1, &sa_usr1, NULL);

    /* Classic sigsuspend() pattern: block the signals we care about,
     * remember the old mask, arm the timer, then atomically unblock
     * and sleep until one of them arrives. This suspends the process
     * (no CPU burned busy-waiting) while it waits for the alarm. */
    sigset_t block_mask, orig_mask;
    sigemptyset(&block_mask);
    sigaddset(&block_mask, SIGALRM);
    sigaddset(&block_mask, SIGUSR1);
    sigprocmask(SIG_BLOCK, &block_mask, &orig_mask);

    if (delay_seconds < 1) delay_seconds = 1;
    alarm((unsigned int)delay_seconds);

    while (!g_fired && !g_cancelled) {
        sigsuspend(&orig_mask);
    }

    if (g_fired) {
        db_mark_triggered(db, alarm_id);
        fprintf(stdout, "\n[alarm-worker pid=%d] \xE2\x8F\xB0 ALARM! \"%s\" (id=%lld) is going off now.\n",
                (int)getpid(), label ? label : "", alarm_id);
        fflush(stdout);
    } else {
        alarm(0); /* defuse the pending timer, just in case */
        db_mark_cancelled(db, alarm_id);
        fprintf(stdout, "[alarm-worker pid=%d] alarm \"%s\" (id=%lld) cancelled.\n",
                (int)getpid(), label ? label : "", alarm_id);
        fflush(stdout);
    }

    db_close(db);
    exit(0);
}
