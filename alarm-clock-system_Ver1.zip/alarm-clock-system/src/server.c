/*
 * Alarm Clock System - main server.
 *
 * A small C HTTP server that:
 *   - serves the web UI (public/index.html, style.css, app.js)
 *   - exposes a tiny JSON API for creating / listing / cancelling alarms
 *   - for each alarm, fork()s a dedicated worker process that uses
 *     alarm(2) + SIGALRM + sigsuspend(2) to wait for the alarm time
 *     without busy-waiting, and can be cancelled with SIGUSR1
 *   - uses a shared SQLite database file as the IPC/persistence layer
 *     between this server process and the per-alarm worker processes
 *
 * Everything runs in Linux user space; no kernel modification.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <unistd.h>
#include <time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "db.h"
#include "http.h"
#include "alarm_worker.h"

#define DEFAULT_PORT 8080
#define JSON_BUF_SIZE (1 << 16)

static sqlite3 *g_db = NULL;
static char g_db_path[512];
static char g_public_dir[512];
static int g_listen_fd = -1;

/* Reap finished alarm-worker children so they don't become zombies.
 * waitpid() and errno assignment are async-signal-safe, so this is
 * fine to run directly in the handler. */
static void sigchld_handler(int sig) {
    (void)sig;
    int saved_errno = errno;
    while (waitpid(-1, NULL, WNOHANG) > 0) { }
    errno = saved_errno;
}

static int path_is_safe(const char *path) {
    return strstr(path, "..") == NULL;
}

static void serve_static(int fd, const char *path) {
    if (!path_is_safe(path)) {
        const char *msg = "{\"error\":\"bad path\"}";
        http_send_response(fd, 400, "Bad Request", "application/json", msg, strlen(msg));
        return;
    }
    char filepath[1024];
    if (strcmp(path, "/") == 0) {
        snprintf(filepath, sizeof(filepath), "%s/index.html", g_public_dir);
    } else {
        snprintf(filepath, sizeof(filepath), "%s%s", g_public_dir, path);
    }
    http_send_file(fd, filepath);
}

static void handle_get_alarms(int fd) {
    char *json = malloc(JSON_BUF_SIZE);
    if (!json) { http_send_json(fd, 500, "{\"error\":\"oom\"}"); return; }
    if (db_alarms_to_json(g_db, json, JSON_BUF_SIZE) < 0) {
        http_send_json(fd, 500, "{\"error\":\"query failed\"}");
    } else {
        http_send_json(fd, 200, json);
    }
    free(json);
}

/* POST /api/alarms  { "label": "...", "delay_seconds": N }
 * Inserts the alarm row, then fork()s a dedicated worker process to
 * own its timer/signal lifecycle. */
static void handle_post_alarms(int fd, const http_request_t *req) {
    char label[256];
    if (json_get_string(req->body, "label", label, sizeof(label)) != 0) {
        snprintf(label, sizeof(label), "Alarm");
    }
    long delay_seconds = json_get_int(req->body, "delay_seconds", -1);
    if (delay_seconds < 1) {
        const char *msg = "{\"error\":\"delay_seconds must be a positive integer\"}";
        http_send_response(fd, 400, "Bad Request", "application/json", msg, strlen(msg));
        return;
    }

    time_t trigger_at = time(NULL) + delay_seconds;
    long long id = db_insert_alarm(g_db, label, (int)delay_seconds, trigger_at);
    if (id < 0) {
        http_send_json(fd, 500, "{\"error\":\"could not create alarm\"}");
        return;
    }

    pid_t pid = fork();
    if (pid < 0) {
        http_send_json(fd, 500, "{\"error\":\"fork failed\"}");
        return;
    }

    if (pid == 0) {
        /* Child: this process's whole job in life is this one alarm. */
        close(g_listen_fd);
        close(fd);
        run_alarm_worker(g_db_path, id, (int)delay_seconds, label); /* never returns */
    }

    /* Parent: record which pid owns this alarm (needed for cancellation)
     * and tell the client the alarm was scheduled. */
    db_set_pid(g_db, id, pid);

    char json[512];
    snprintf(json, sizeof(json),
             "{\"id\":%lld,\"pid\":%d,\"trigger_at\":%lld,\"status\":\"active\"}",
             id, (int)pid, (long long)trigger_at);
    http_send_json(fd, 200, json);
}

/* POST /api/alarms/<id>/cancel
 * Signals the owning worker process; the worker updates its own DB
 * status once it wakes up and handles SIGUSR1. */
static void handle_cancel_alarm(int fd, long long id) {
    pid_t pid = 0;
    char status[32] = {0};
    if (db_get_pid_status(g_db, id, &pid, status, sizeof(status)) != 0) {
        http_send_json(fd, 404, "{\"error\":\"no such alarm\"}");
        return;
    }
    if (strcmp(status, "active") != 0 || pid <= 0) {
        http_send_json(fd, 400, "{\"error\":\"alarm is not active\"}");
        return;
    }
    if (kill(pid, SIGUSR1) != 0) {
        http_send_json(fd, 500, "{\"error\":\"could not signal worker\"}");
        return;
    }
    http_send_json(fd, 200, "{\"ok\":true}");
}

static void handle_clear_finished(int fd) {
    db_clear_finished(g_db);
    http_send_json(fd, 200, "{\"ok\":true}");
}

static void route(int fd, const http_request_t *req) {
    long long id;

    if (strcmp(req->method, "GET") == 0 && strcmp(req->path, "/api/alarms") == 0) {
        handle_get_alarms(fd);
    } else if (strcmp(req->method, "POST") == 0 && strcmp(req->path, "/api/alarms") == 0) {
        handle_post_alarms(fd, req);
    } else if (strcmp(req->method, "POST") == 0 &&
               sscanf(req->path, "/api/alarms/%lld/cancel", &id) == 1) {
        handle_cancel_alarm(fd, id);
    } else if (strcmp(req->method, "POST") == 0 && strcmp(req->path, "/api/alarms/clear") == 0) {
        handle_clear_finished(fd);
    } else if (strcmp(req->method, "GET") == 0) {
        serve_static(fd, req->path);
    } else {
        const char *msg = "{\"error\":\"not found\"}";
        http_send_response(fd, 404, "Not Found", "application/json", msg, strlen(msg));
    }
}

int main(int argc, char **argv) {
    int port = DEFAULT_PORT;
    if (argc > 1) port = atoi(argv[1]);

    snprintf(g_db_path, sizeof(g_db_path), "%s",
             (argc > 2) ? argv[2] : "db/alarms.db");
    snprintf(g_public_dir, sizeof(g_public_dir), "%s",
             (argc > 3) ? argv[3] : "public");

    signal(SIGPIPE, SIG_IGN); /* don't die if a client disconnects mid-write */

    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = sigchld_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESTART; /* let accept() keep blocking across SIGCHLD */
    sigaction(SIGCHLD, &sa, NULL);

    g_db = db_open(g_db_path);
    if (!g_db) {
        fprintf(stderr, "failed to open database at %s\n", g_db_path);
        return 1;
    }

    g_listen_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (g_listen_fd < 0) { perror("socket"); return 1; }

    int opt = 1;
    setsockopt(g_listen_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons((uint16_t)port);

    if (bind(g_listen_fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("bind");
        return 1;
    }
    if (listen(g_listen_fd, 32) < 0) {
        perror("listen");
        return 1;
    }

    printf("Alarm Clock System server listening on http://localhost:%d\n", port);
    printf("Database: %s | Static files: %s\n", g_db_path, g_public_dir);
    fflush(stdout);

    for (;;) {
        struct sockaddr_in client_addr;
        socklen_t client_len = sizeof(client_addr);
        int client_fd = accept(g_listen_fd, (struct sockaddr *)&client_addr, &client_len);
        if (client_fd < 0) {
            if (errno == EINTR) continue;
            perror("accept");
            continue;
        }

        http_request_t req;
        if (http_read_request(client_fd, &req) == 0) {
            route(client_fd, &req);
        }
        close(client_fd);
    }

    db_close(g_db);
    close(g_listen_fd);
    return 0;
}
