#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "db.h"

static const char *CREATE_TABLE_SQL =
    "CREATE TABLE IF NOT EXISTS alarms ("
    "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
    "  label TEXT NOT NULL,"
    "  delay_seconds INTEGER NOT NULL,"
    "  created_at INTEGER NOT NULL,"
    "  trigger_at INTEGER NOT NULL,"
    "  status TEXT NOT NULL DEFAULT 'active'," /* active | triggered | cancelled */
    "  pid INTEGER NOT NULL DEFAULT 0"
    ");";

sqlite3 *db_open(const char *path) {
    sqlite3 *db = NULL;
    if (sqlite3_open(path, &db) != SQLITE_OK) {
        fprintf(stderr, "db_open: %s\n", sqlite3_errmsg(db));
        return NULL;
    }

    /* WAL mode + a busy timeout let the server process and the short-lived
     * per-alarm worker processes touch the same file concurrently without
     * "database is locked" errors. */
    sqlite3_busy_timeout(db, 3000);
    char *errmsg = NULL;
    sqlite3_exec(db, "PRAGMA journal_mode=WAL;", NULL, NULL, &errmsg);
    if (errmsg) { sqlite3_free(errmsg); errmsg = NULL; }

    if (sqlite3_exec(db, CREATE_TABLE_SQL, NULL, NULL, &errmsg) != SQLITE_OK) {
        fprintf(stderr, "db_open: create table failed: %s\n", errmsg);
        sqlite3_free(errmsg);
        sqlite3_close(db);
        return NULL;
    }
    return db;
}

void db_close(sqlite3 *db) {
    if (db) sqlite3_close(db);
}

long long db_insert_alarm(sqlite3 *db, const char *label,
                           int delay_seconds, time_t trigger_at) {
    const char *sql =
        "INSERT INTO alarms (label, delay_seconds, created_at, trigger_at, status, pid) "
        "VALUES (?, ?, strftime('%s','now'), ?, 'active', 0);";
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) != SQLITE_OK) return -1;

    sqlite3_bind_text(stmt, 1, label, -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 2, delay_seconds);
    sqlite3_bind_int64(stmt, 3, (sqlite3_int64)trigger_at);

    long long id = -1;
    if (sqlite3_step(stmt) == SQLITE_DONE) {
        id = sqlite3_last_insert_rowid(db);
    }
    sqlite3_finalize(stmt);
    return id;
}

int db_set_pid(sqlite3 *db, long long id, pid_t pid) {
    const char *sql = "UPDATE alarms SET pid = ? WHERE id = ?;";
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) != SQLITE_OK) return -1;
    sqlite3_bind_int(stmt, 1, (int)pid);
    sqlite3_bind_int64(stmt, 2, id);
    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return (rc == SQLITE_DONE) ? 0 : -1;
}

static int mark_status_if_active(sqlite3 *db, long long id, const char *new_status) {
    const char *sql = "UPDATE alarms SET status = ? WHERE id = ? AND status = 'active';";
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) != SQLITE_OK) return -1;
    sqlite3_bind_text(stmt, 1, new_status, -1, SQLITE_STATIC);
    sqlite3_bind_int64(stmt, 2, id);
    int rc = sqlite3_step(stmt);
    int changed = sqlite3_changes(db);
    sqlite3_finalize(stmt);
    return (rc == SQLITE_DONE && changed > 0) ? 0 : -1;
}

int db_mark_triggered(sqlite3 *db, long long id) {
    return mark_status_if_active(db, id, "triggered");
}

int db_mark_cancelled(sqlite3 *db, long long id) {
    return mark_status_if_active(db, id, "cancelled");
}

int db_get_pid_status(sqlite3 *db, long long id, pid_t *pid, char *status_out, size_t status_len) {
    const char *sql = "SELECT pid, status FROM alarms WHERE id = ?;";
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) != SQLITE_OK) return -1;
    sqlite3_bind_int64(stmt, 1, id);

    int rc = -1;
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        if (pid) *pid = (pid_t)sqlite3_column_int(stmt, 0);
        const unsigned char *s = sqlite3_column_text(stmt, 1);
        if (status_out && s) {
            snprintf(status_out, status_len, "%s", (const char *)s);
        }
        rc = 0;
    }
    sqlite3_finalize(stmt);
    return rc;
}

/* Very small JSON string escaper: handles the characters that can
 * plausibly show up in a user-typed alarm label. */
static void json_escape_append(char *buf, size_t buflen, size_t *pos, const char *s) {
    for (; *s && *pos < buflen - 1; s++) {
        unsigned char c = (unsigned char)*s;
        if (c == '"' || c == '\\') {
            if (*pos + 2 >= buflen) break;
            buf[(*pos)++] = '\\';
            buf[(*pos)++] = c;
        } else if (c == '\n') {
            if (*pos + 2 >= buflen) break;
            buf[(*pos)++] = '\\';
            buf[(*pos)++] = 'n';
        } else if (c < 0x20) {
            /* skip other control chars */
        } else {
            buf[(*pos)++] = c;
        }
    }
}

int db_alarms_to_json(sqlite3 *db, char *buf, size_t buflen) {
    const char *sql =
        "SELECT id, label, delay_seconds, created_at, trigger_at, status, pid "
        "FROM alarms ORDER BY id DESC;";
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) != SQLITE_OK) return -1;

    size_t pos = 0;
    buf[pos++] = '[';
    int first = 1;

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        if (!first) buf[pos++] = ',';
        first = 0;

        long long id = sqlite3_column_int64(stmt, 0);
        const unsigned char *label = sqlite3_column_text(stmt, 1);
        int delay_seconds = sqlite3_column_int(stmt, 2);
        long long created_at = sqlite3_column_int64(stmt, 3);
        long long trigger_at = sqlite3_column_int64(stmt, 4);
        const unsigned char *status = sqlite3_column_text(stmt, 5);
        int pid = sqlite3_column_int(stmt, 6);

        char row[768];
        size_t rpos = 0;
        rpos += snprintf(row, sizeof(row),
            "{\"id\":%lld,\"label\":\"", id);
        json_escape_append(row, sizeof(row), &rpos, label ? (const char *)label : "");
        rpos += snprintf(row + rpos, sizeof(row) - rpos,
            "\",\"delay_seconds\":%d,\"created_at\":%lld,\"trigger_at\":%lld,"
            "\"status\":\"%s\",\"pid\":%d}",
            delay_seconds, created_at, trigger_at,
            status ? (const char *)status : "unknown", pid);

        if (pos + rpos >= buflen - 2) { sqlite3_finalize(stmt); return -1; }
        memcpy(buf + pos, row, rpos);
        pos += rpos;
    }

    buf[pos++] = ']';
    buf[pos] = '\0';
    sqlite3_finalize(stmt);
    return (int)pos;
}

int db_clear_finished(sqlite3 *db) {
    char *errmsg = NULL;
    int rc = sqlite3_exec(db, "DELETE FROM alarms WHERE status != 'active';", NULL, NULL, &errmsg);
    if (errmsg) { fprintf(stderr, "db_clear_finished: %s\n", errmsg); sqlite3_free(errmsg); }
    return (rc == SQLITE_OK) ? 0 : -1;
}
