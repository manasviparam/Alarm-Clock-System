#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <strings.h>
#include <unistd.h>
#include <sys/socket.h>
#include "http.h"

/* Small portable case-insensitive substring search (avoids depending on
 * the GNU strcasestr extension / _GNU_SOURCE). */
static const char *strcasestr_local(const char *haystack, const char *needle) {
    size_t nlen = strlen(needle);
    for (const char *h = haystack; *h; h++) {
        if (strncasecmp(h, needle, nlen) == 0) return h;
    }
    return NULL;
}

int http_read_request(int fd, http_request_t *req) {
    static char buf[HTTP_MAX_REQUEST];
    size_t total = 0;
    ssize_t n;

    memset(req, 0, sizeof(*req));

    /* Read until we have the blank line that ends the headers. */
    char *header_end = NULL;
    while (total < sizeof(buf) - 1) {
        n = recv(fd, buf + total, sizeof(buf) - 1 - total, 0);
        if (n <= 0) {
            if (total == 0) return -1;
            break;
        }
        total += (size_t)n;
        buf[total] = '\0';
        header_end = strstr(buf, "\r\n\r\n");
        if (header_end) break;
    }
    if (!header_end) return -1;

    /* Request line: METHOD PATH HTTP/1.x */
    if (sscanf(buf, "%7s %511s", req->method, req->path) != 2) return -1;

    /* Content-Length (case-insensitive-ish; browsers/fetch send it capitalized). */
    long content_length = 0;
    const char *cl = strcasestr_local(buf, "Content-Length:");
    if (cl) content_length = atol(cl + strlen("Content-Length:"));

    size_t headers_len = (size_t)(header_end - buf) + 4;
    size_t body_have = total - headers_len;

    if (content_length > 0) {
        if ((size_t)content_length >= sizeof(req->body)) content_length = sizeof(req->body) - 1;
        size_t to_copy = body_have < (size_t)content_length ? body_have : (size_t)content_length;
        memcpy(req->body, buf + headers_len, to_copy);
        size_t got = to_copy;
        /* Keep reading if the body arrived in more than one TCP segment. */
        while (got < (size_t)content_length) {
            n = recv(fd, req->body + got, (size_t)content_length - got, 0);
            if (n <= 0) break;
            got += (size_t)n;
        }
        req->body[got] = '\0';
        req->body_len = got;
    }

    return 0;
}

void http_send_response(int fd, int status_code, const char *status_text,
                         const char *content_type, const char *body, size_t body_len) {
    char header[512];
    int hlen = snprintf(header, sizeof(header),
        "HTTP/1.1 %d %s\r\n"
        "Content-Type: %s\r\n"
        "Content-Length: %zu\r\n"
        "Connection: close\r\n"
        "\r\n",
        status_code, status_text, content_type, body_len);
    send(fd, header, (size_t)hlen, 0);
    if (body_len > 0) send(fd, body, body_len, 0);
}

void http_send_json(int fd, int status_code, const char *json) {
    const char *text = (status_code == 200) ? "OK" : (status_code == 404 ? "Not Found" : "Bad Request");
    http_send_response(fd, status_code, text, "application/json", json, strlen(json));
}

static const char *guess_content_type(const char *path) {
    const char *ext = strrchr(path, '.');
    if (!ext) return "application/octet-stream";
    if (strcmp(ext, ".html") == 0) return "text/html";
    if (strcmp(ext, ".css") == 0) return "text/css";
    if (strcmp(ext, ".js") == 0) return "application/javascript";
    if (strcmp(ext, ".json") == 0) return "application/json";
    return "application/octet-stream";
}

void http_send_file(int fd, const char *filepath) {
    FILE *f = fopen(filepath, "rb");
    if (!f) {
        const char *msg = "{\"error\":\"not found\"}";
        http_send_response(fd, 404, "Not Found", "application/json", msg, strlen(msg));
        return;
    }
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);

    char *data = malloc((size_t)size);
    if (!data) { fclose(f); return; }
    if (fread(data, 1, (size_t)size, f) != (size_t)size) { /* best effort */ }
    fclose(f);

    http_send_response(fd, 200, "OK", guess_content_type(filepath), data, (size_t)size);
    free(data);
}

int json_get_string(const char *json, const char *key, char *out, size_t out_len) {
    char pattern[128];
    snprintf(pattern, sizeof(pattern), "\"%s\"", key);
    const char *p = strstr(json, pattern);
    if (!p) return -1;
    p = strchr(p + strlen(pattern), ':');
    if (!p) return -1;
    p++;
    while (*p == ' ' || *p == '\t') p++;
    if (*p != '"') return -1;
    p++;
    size_t i = 0;
    while (*p && *p != '"' && i < out_len - 1) {
        if (*p == '\\' && *(p + 1)) p++; /* skip escape char, copy the next literally */
        out[i++] = *p++;
    }
    out[i] = '\0';
    return 0;
}

long json_get_int(const char *json, const char *key, long default_value) {
    char pattern[128];
    snprintf(pattern, sizeof(pattern), "\"%s\"", key);
    const char *p = strstr(json, pattern);
    if (!p) return default_value;
    p = strchr(p + strlen(pattern), ':');
    if (!p) return default_value;
    p++;
    return strtol(p, NULL, 10);
}
